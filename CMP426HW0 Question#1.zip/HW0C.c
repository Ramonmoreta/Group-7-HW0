 /* collatz Conjecture Question 1 Hw0 in c programming */
/*Eliazar Contreras
Ramon Moreta de la cruz
Jeuris De la Rosa
Ilham Benzekri
*/

#include<stdio.h>

#include <unistd.h>

#include <sys/types.h>


int main(){


pid_t pid;

int n=0;

int m=0;


do{


printf("Enter a positive number to run the Collatz Conjecture?\n");


scanf("%d", &m);


}while (m <= 0);


pid = fork(); //system call creates new process


if (pid == 0) //child process

{

 printf("Child is working\n");

 printf("%d\n", m);


while (m!=1)

{ 

 if(m%2==1) //m is odd

 {  

  m=3*m+1;;

 }

 else if(m%2==0) //m is even

 {

  m=m/2;

 }

 printf("%d\n", m);

}


 printf("child process Done\n");

}

else //parent process

{

 printf("Parent Wait\n");

wait(); //parent will wait for the child to complete



printf("Parent Done\n");

}

return 0;

}

