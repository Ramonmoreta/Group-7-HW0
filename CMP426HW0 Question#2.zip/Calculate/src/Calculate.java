/***Eliazar Contreras
 * Ramon Moreta De la Cruz
 * Jeuris De La Rosa
 * Ilham Benzekri
**/

import java.util.Scanner;
import java.math.*;
public class Calculate {
 
	static int n;
 //Creates the Scanner (input from user)
 static Scanner Scan = new Scanner(System.in);

 public static void cal(int n) {
	 for (int i = 0; i <= n; i++) {
		 //Define when i is an odd Number
		 if (i % 2 == 1) {
	    //print the odd values on a single line
			 System.out.print(i + " ");
		 }
	 }

 }
	
	
	
	
	
	
	
	public static void main(String[] args) {
		//Ask the user for a Whole Number
		 System.out.println("Enter your Number:");
		 n = Scan.nextInt();
	  // Call the function cal
		 cal(n);
	}
}

