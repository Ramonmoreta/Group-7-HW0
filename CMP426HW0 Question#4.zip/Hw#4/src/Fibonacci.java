//Jeuris De La Rosa
//Ramon Moreta De La Cruz
//Eliazar Contreras
//Ilham Benzekri
//CMP 426 Homework #0 Question #4

import java.util.Scanner; //Imports the scanner for the user prompt section
public class Fibonacci {
	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in); //Creating a scanner to prompt the user to enter a number of terms for the Fibonacci sequence
		System.out.print("Enter the number of terms for the Fibonacci sequence: "); //Asking the user what the program needs them to put in
		int n = reader.nextInt(); //The prompt value goes into this variable
		reader.close(); //This is the end of the user prompt section

		int n1 = 0; //First number to add
		int n2 = 1; //Second number to add
		int total = 0; //The total sum of the Fibonacci sequence base on the nth term
		System.out.print("First " + n + " terms: "); //Prints out the number of terms that the user has put in

		for (int i = 1; i <= n; i++) //For loop that allows the addition of the next term until it reaches the nth term
		{
			if (i == 1)
				System.out.print(n1); //Prints out the 0 value to make the output look nice

			int sum = n1 + n2; //Adds the first two terms and inserts it to the current sum
			n1 = n2; //n1's value gets replaced by the current n2's value
			n2 = sum; //n2's value gets replaced by the next term (or the current sum)
			total = sum - 1; //The total is "sum - 1" because "sum" starts out as 1
			
			if (i != n)
				System.out.print(" + " + n1); //Prints out the next terms
		}
		System.out.print(" = " + total); //Prints out the total
	}
}
