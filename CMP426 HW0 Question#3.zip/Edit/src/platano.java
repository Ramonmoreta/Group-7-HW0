//Ramon Moreta De la cruz
//Eliazar contreras
//Jeuris De LA Rosa 
//Ilham Benzekri
import java.util.Scanner;
public class platano {
	public static void salami () {
		int length;
		//Creates a  Scanner Name input
		Scanner input = new Scanner (System.in);

		// Ask User The size of the array
		System.out.println("How many number are you going to Enter:  ");
				length = input.nextInt();
	// Setting a new array call Mangu
		int [] mangu = new int[length];
		//Ask the user for the values of the numbers to enter
		System.out.println("Enter numbers: " );
		//This for loop insert the numbers into the array
		for(int n =0; n < length; n++) {
			mangu[n] = input.nextInt();
		}
		input.close();
		
		// Find the maximum value in the array. 
		int max = mangu [0];
		for(int i = 0; i < mangu.length; i++) {
			if(mangu [i] > max) {
				max = mangu[i];
			}
		}
		//Find the minimum value in the array 
	int min = mangu [0];
		for (int x = 0; x < mangu.length; x++) {
			if(mangu [x] < min) {
				min = mangu[x]; 
			}
		}
		//the program is going to calculate the average value 
		int y, sum, avg; 
		sum = 0;
		
		for(y = 0; y < mangu.length; y++) {
			sum += mangu[y];
		}
		avg = sum / mangu.length;
		//print out the average, minimum and maximum. 
		System.out.println(" The average values is " + avg);
		System.out.println(" The minimum value is " + min);
		System.out.println(" The maximum value is " + max);
	}
	//the program main 
	public static void main(String [] args) {
		//calling the method salami() 
       salami();
	
	
	}
}
